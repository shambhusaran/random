const ProductController = require('./product.controller.js')
const MiscController = require('./misc.controller.js')
module.exports = {ProductController,MiscController}