const RegisterController = require('./register.controller.js')
const LoginController = require('./login.controller.js')

module.exports = {RegisterController, LoginController}