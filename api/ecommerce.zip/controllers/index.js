const Auth = require('./auth')
const Profile = require('./profile')
const Cms = require('./cms')
const Front = require('./front')

module.exports = {Auth, Profile, Cms, Front}