const ProfileController = require('./profile.controller.js')
module.exports = {ProfileController}